#ifndef matrix_addition_improved_h
#define matrix_addition_improved_h

#include <vector>

std::vector < std::vector <int> > matrix_addition(std::vector < std::vector <int> > matrixa, std::vector < std::vector <int> > matrixb);

#endif /* matrix_addition_improved_h */

