#ifndef unreserved_hpp
#define unreserved_hpp

#include <vector>

std::vector< std::vector<int> > unreserved(int rows, int cols, int initial_value);

#endif /* unreserved_hpp */
