#ifndef reserved_hpp
#define reserved_hpp

#include <vector>

std::vector< std::vector<int> > reserved(int rows, int cols, int initial_value);

#endif /* reserved_hpp */
