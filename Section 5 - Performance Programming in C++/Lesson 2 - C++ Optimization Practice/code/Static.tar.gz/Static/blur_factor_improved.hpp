#ifndef blur_factor_improved_hpp
#define blur_factor_improved_hpp

#include <vector>
std::vector < std::vector <float> > blur_factor_improved();

#endif /* blur_factor_improved_hpp */
